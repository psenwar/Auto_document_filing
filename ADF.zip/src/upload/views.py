from django.shortcuts import render
from django.http import HttpResponse  
from upload.functions import handle_uploaded_file  #functions.py
from upload.forms import StudentForm,ProductForm #forms.py

from django.core.files.storage import FileSystemStorage
from pathlib import Path
BASE_DIR = Path(__file__).resolve().parent.parent

# Create your views here.

def index(request):  
    if request.method == 'POST':  
        student = StudentForm(request.POST, request.FILES)  
        if student.is_valid():  
            handle_uploaded_file(request.FILES['file'])  
            model_instance = student.save(commit=False)
            model_instance.save()
            return HttpResponse("File uploaded successfuly")  
    else:  
        student = StudentForm()  
        return render(request,"index.html",{'form':student}) 

def home_view(request,*args,**kwargs):
	return render(request,"home_page.html",{}) # string of html code

def upload_doc(request):
    form  = ProductForm(request.POST or None)
    if form.is_valid():
        form.save()
    context = {
        'form':form
    }
    return render(request,"upload_page.html",context)

def upload(request):
    context = {}
    if request.method == 'POST':
        uploaded_file = request.FILES['document']
        fs = FileSystemStorage()
        file_name  = fs.save(uploaded_file.name,uploaded_file)
        file_path = fs.url(file_name)
        context['url'] = fs.url(file_name)
        print("base directory",BASE_DIR,type(BASE_DIR))
        print(file_path,type(file_path))
        print("path" , str(BASE_DIR)+file_path)   # full location of our file
        print(file_name)
    return render(request,'index.html',context)

from .models import Book
def book_list(request):
    books = Book.objects.all()
    return render(request, 'book_list.html', {
        'books': books
    })

from .forms import BookForm
from django.shortcuts import redirect

def upload_book(request):
    if request.method == 'POST':
        form = BookForm(request.POST, request.FILES)
        if form.is_valid():
            form.save()
            return redirect(book_list)
    else:
        form = BookForm()
    context = {
      'form': form
    }
    return render(request,"upload_book.html",context)