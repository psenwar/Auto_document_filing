from django import forms  
from upload.models import StudentForm,Upload_Doc,Book  #models.py
    
class StudentForm(forms.ModelForm):  
    class Meta:  
        model = StudentForm  
        fields = "__all__"


class ProductForm(forms.ModelForm):
    class Meta:
        model =  Upload_Doc
        fields = [
           'title',
           'description',
        ]


class BookForm(forms.ModelForm):
    class Meta:
        model = Book
        fields = ('title', 'author', 'pdf')