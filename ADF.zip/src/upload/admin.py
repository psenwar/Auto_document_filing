from django.contrib import admin

# Register your models here.
from .models import Upload_Doc, StudentForm
admin.site.register(Upload_Doc)
admin.site.register(StudentForm)